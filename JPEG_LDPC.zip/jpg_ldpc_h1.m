clear; clc; close all;

%% =============================
%     输入输出路径设定
%% =============================
tx_img_dir   = "test";
mid_img_dir  = "images_mid_h1";
rx_root      = "jpg_img_h1";

if ~exist(rx_root,'dir'), mkdir(rx_root); end
if ~exist(mid_img_dir,'dir'), mkdir(mid_img_dir); end

%% =============================
%     LDPC 初始化（先保留）
%% =============================
H2 = load("H1.mat");
H2 = sparse(H2.H ~= 0);
[m2, n2] = size(H2);
k2 = n2 - m2;
maxnumiter = 20;
cfgEnc2 = ldpcEncoderConfig(H2);
cfgDec2 = ldpcDecoderConfig(H2);

%% =============================
%       遍历文件
%% =============================
tx_files = dir(fullfile(tx_img_dir, "*.jpg"));

SNR_list = 0:2:16;

for si = 1:length(SNR_list)

    SNR = SNR_list(si);

    snr_dir = fullfile(rx_root, sprintf('SNR_%d', SNR));
    rx_img_dir   = fullfile(snr_dir, "images");
    mid_jpg_dir  = fullfile(snr_dir, "jpg_patches");
    rx_patch_dir = fullfile(snr_dir, "rx_patches");

    if ~exist(rx_img_dir,'dir'), mkdir(rx_img_dir); end
    if ~exist(mid_jpg_dir,'dir'), mkdir(mid_jpg_dir); end
    if ~exist(rx_patch_dir,'dir'), mkdir(rx_patch_dir); end
    h0 = 0;

    for fi = 1:length(tx_files)

        %% =============================
        % 1. 读取原图
        %% =============================
        filename = tx_files(fi).name;
        inputpath = fullfile(tx_img_dir, filename);
        base = erase(filename, ".jpg");

        img = imread(inputpath);

        blockSize = 32;
        recon_img = zeros(size(img), 'uint8');

        block_idx = 1;   % ✅ 修复：必须在外面定义

        for i = 1:blockSize:size(img,1)
            for j = 1:blockSize:size(img,2)

                %% =============================
                % 2. 切块 + JPG压缩
                %% =============================
                patch = img(i:i+blockSize-1, j:j+blockSize-1, :);

                import java.io.*
                import javax.imageio.ImageIO
                
                % uint8 -> BufferedImage
                tmpfile = [tempname '.jpg'];
                
                imwrite(patch, tmpfile, 'jpg', 'Quality', 50);
                
                fid = fopen(tmpfile,'rb');
                byteStream = fread(fid,'uint8');
                fclose(fid);
                
                delete(tmpfile);


                %patchName = sprintf('%s_%d_%d.jpg', base, i, j);
                %patchPath = fullfile(mid_jpg_dir, patchName);

                % 👉 JPG压缩（可调质量）
                %imwrite(patch, patchPath,"jpg", 'Quality', 50);

                %% =============================
                % 3. 读JPG → bit
                %% =============================
                %fid = fopen(patchPath, 'rb');
                %byteStream = fread(fid, 'uint8');
                %fclose(fid);

                

                bitStream = de2bi(double(byteStream), 8, 'left-msb')';
                bits = bitStream(:);
                img_len = length(bits);
                %% =============================
                % 4. 信道（可加LDPC/BPSK）
                %% =============================
                % ===== 这里你可以插入 LDPC =====

                    numBlocks_img = ceil(img_len / k2);
                    pad_img = numBlocks_img*k2 - img_len;
                    img_pad = [bits; zeros(pad_img,1)];
               
                    rx_bits_img_all = zeros(numBlocks_img*k2,1);
                    s=0;
                    for b = 1:numBlocks_img
                        idx = (b-1)*k2 + 1 : b*k2;
                        info = img_pad(idx);
                        % LDPC
                        cw = ldpcEncode(info, cfgEnc2);
                        % BPSK
                        modsig = bpskmod(double(cw)); 
                        Pn = 1 / 10^(SNR/10);
                        K=10;
                        
                        h0=h0+1;
                        %if h0>100000,fprintf("h0→ %d\n,mc→ %d\n", h0,mc);end
                        %if h0>100000,stopAll = true;end  

                        h2_nlos = 1/sqrt(2) * (randn + 1i*randn);
                        h2 = (sqrt(K/(K+1)) + sqrt(1/(K+1)) * h2_nlos );
                        rx_img_sig = modsig * h2;

                        n2 = sqrt(Pn/2)*(randn(size(rx_img_sig)) + 1i*randn(size(rx_img_sig)));
                        rx_img_sig = rx_img_sig + n2;

                        var = 1/(10^(SNR/10));
                        rx_img_llr   = bpskdemod(rx_img_sig, h2, var, 'llr');
                        
                        dec2 = ldpcDecode(rx_img_llr, cfgDec2, maxnumiter);
                        info2 = dec2(:); 
                        rx_bits_img_all((b-1)*k2 + 1 : b*k2) = info2;
                
                    end
                    rx_img_bits = rx_bits_img_all(1:img_len);

                rx_bits = rx_img_bits;

                %% =============================
                % 5. bit → byte
                %% =============================
                
                % ===== bit合法化 =====
                rx_bits = double(rx_bits(:) > 0);
                
                % ===== 长度修正 =====
                valid_len = floor(length(rx_bits)/8)*8;
                
                rx_bits = rx_bits(1:valid_len);
                
                % ===== 空数据保护 =====
                if isempty(rx_bits)
                
                    patch_rec = zeros(blockSize,blockSize,3,'uint8');
                
                    hh = i_end - i + 1;
                    ww = j_end - j + 1;
                
                    recon_img(i:i_end,j:j_end,:) = patch_rec(1:hh,1:ww,:);
                
                    continue;
                
                end
                
                rx_bytes = bi2de(reshape(rx_bits,8,[])','left-msb');
                
                
                %% =============================
                % 7. 读取恢复 patch
                %% =============================
                
                valid_jpg = false;
                
                % ===== JPEG合法性检测 =====
                if length(rx_bytes) > 4
                
                    if rx_bytes(1)==255 && rx_bytes(2)==216 && ...
                       rx_bytes(end-1)==255 && rx_bytes(end)==217
                
                        valid_jpg = true;
                
                    end
                end
                
                if valid_jpg
                
                    % ===== 写临时文件 =====
                    tmpfile2 = [tempname '.jpg'];
                
                    fid = fopen(tmpfile2,'wb');
                    fwrite(fid, rx_bytes, 'uint8');
                    fclose(fid);
                
                    % ===== 文件大小保护 =====
                    fileinfo = dir(tmpfile2);
                
                    % 正常32×32 JPEG通常只有几KB
                    % 超大说明JPEG已损坏
                
                    if isempty(fileinfo) || fileinfo.bytes > 200000
                
                        patch_rec = zeros(blockSize,blockSize,3,'uint8');
                
                        if isfile(tmpfile2)
                            delete(tmpfile2);
                        end
                
                        hh = i_end - i + 1;
                        ww = j_end - j + 1;
                
                        recon_img(i:i_end,j:j_end,:) = patch_rec(1:hh,1:ww,:);
                
                        continue;
                
                    end
                
                    try
                
                        % ===== JPEG信息检查 =====
                        info = imfinfo(tmpfile2);
                
                        if isempty(info) || ...
                           info.Width <= 0 || ...
                           info.Height <= 0 || ...
                           info.Width > 256 || ...
                           info.Height > 256
                
                            patch_rec = zeros(blockSize,blockSize,3,'uint8');
                
                        else
                
                            patch_rec = imread(tmpfile2);
                
                        end
                
                        % ===== 空图保护 =====
                        if isempty(patch_rec)
                
                            patch_rec = zeros(blockSize,blockSize,3,'uint8');
                
                        end
                
                        [h,w,c] = size(patch_rec);
                
                        % ===== 灰度图转RGB =====
                        if c == 1
                
                            patch_rec = repmat(patch_rec,[1 1 3]);
                
                        end
                
                        % ===== 防止异常尺寸 =====
                        h = min(h,blockSize);
                        w = min(w,blockSize);
                
                        patch_rec = patch_rec(1:h,1:w,:);
                
                        % ===== 不足32×32补零 =====
                        if h < blockSize || w < blockSize
                
                            tmp = zeros(blockSize,blockSize,3,'uint8');
                
                            tmp(1:h,1:w,:) = patch_rec;
                
                            patch_rec = tmp;
                
                        end
                
                    catch
                
                        patch_rec = zeros(blockSize,blockSize,3,'uint8');
                
                    end
                
                    % ===== 删除临时文件 =====
                    if isfile(tmpfile2)
                
                        delete(tmpfile2);
                
                    end
                
                else
                
                    % ===== 非法JPEG直接黑块 =====
                    patch_rec = zeros(blockSize,blockSize,3,'uint8');
                
                end
                
                

                %% =============================
                % 8. 拼接
                %% =============================
                recon_img(i:i+blockSize-1, j:j+blockSize-1, :) = patch_rec;

                block_idx = block_idx + 1;

            end
        end

        %% =============================
        % 9. 保存整图
        %% =============================
        outPath = fullfile(rx_img_dir, sprintf('%s.jpg', base));
        imwrite(recon_img, outPath);

        %fprintf("Saved → %s\n", outPath);

    end
end

fprintf("\n==== JPG链路处理完成 ====\n");