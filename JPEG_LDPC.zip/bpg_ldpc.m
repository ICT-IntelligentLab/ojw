 clear; clc; close all;

%% =============================
%     输入输出路径设定
%% =============================
tx_img_dir   = "New Folder";
mid_img_dir   = "images_mid";

rx_root = "bpsk_h1_img_ber";
if ~exist(rx_root,'dir'), mkdir(rx_root); end
if ~exist(mid_img_dir,'dir'), mkdir(mid_img_dir); end

%     LDPC 初始化
H2 = load("H2.mat");
H2 = sparse(H2.H ~= 0);
[m2, n2] = size(H2);
k2 = n2 - m2;       % 信息位长度
cfgEnc2 = ldpcEncoderConfig(H2);
cfgDec2 = ldpcDecoderConfig(H2);
maxnumiter = 20;

%% =============================
%       遍历所有发送文件
%% =============================
tx_files = dir(fullfile(tx_img_dir, "*.png"));

SNR_list = 0:2:16; 

% 统计结果保存
    ber_root = fullfile(rx_root, "ber");
    if ~exist(ber_root,'dir'), mkdir(ber_root); end

    BER_img   = zeros(length(SNR_list), 1);   % 每个 SNR 下图像误码率

for si = 1:length(SNR_list)

    SNR = SNR_list(si);
    snr_dir = fullfile(rx_root, sprintf('SNR_%d', SNR));
    rx_img_dir   = fullfile(snr_dir, "images");
    bpg_dir = fullfile(snr_dir, "bpg_images");
    if ~exist(bpg_dir,'dir'), mkdir(bpg_dir); end
    if ~exist(rx_img_dir,'dir'), mkdir(rx_img_dir); end
    
    img_errors  = 0;

    MC = 1;
    h0=0;
    stopAll = false;

    total_coord_bits = 0;
    total_img_bits   = 0;
    total_bits_all   = 0;

    for mc = 1:MC

    for fi = 1:length(tx_files)%length(tx_files)

    %% 1. 读取图像
    filename = tx_files(fi).name;
    inputpath = fullfile(tx_img_dir, filename);
    base = erase(filename, ".jpg");
    % 读取图片
    img = imread(fullfile(tx_img_dir, filename));
    img_vec1 = img(:);                       % 列向量 [pixels*channels x 1]
    img_bits_mat1 = de2bi(double(img_vec1), 8, 'left-msb'); % 每行一个像素的 8-bit
    img_bits1 = reshape(img_bits_mat1.', [], 1);  % 按列堆叠 -> 列主序，与 de2bi(:) 相对称

    %% 2. BPG 压缩生成比特流
    
    %% 1a. 将 JPEG 解码后保存为 PNG 中间体
    tempPNG = fullfile(mid_img_dir, [base '.png']);
    imwrite(img, tempPNG);

    bpgFile = fullfile(bpg_dir, [base '.bpg']);
    cmd = sprintf('"%s" "%s" -o "%s"', ...
        'D:\Py\matlabCode\BPG_LDPC\bpg\bpgenc.exe', ...
        tempPNG, ...
        bpgFile);
    system(cmd);

    %% 3. 删除中间 PNG
    if exist(tempPNG, 'file')
        delete(tempPNG);
    end
    %system('C:\BPG\bpgenc.exe image.png -o image.bpg');"D:\Py\matlabCode\BPG_LDPC\bpg\bpgenc.exe"
    % 读取BPG文件为二进制比特流
    fid = fopen(bpgFile, 'rb');
    byteStream = fread(fid, 'uint8');
    fclose(fid);
    % 转换为比特流
    bitStream = de2bi(double(byteStream), 8, 'left-msb')';
    img_bits = bitStream(:); % 列向量
                 
    %img_bits_mat = de2bi(double(bitStream), 8, 'left-msb'); % 每行一个像素的 8-bit
    %img_bits = reshape(img_bits_mat.', [], 1);  % 按列堆叠 -> 列主序，与 de2bi(:) 相对称
    img_len = length(img_bits);


    %% ======================================================
    %              Part B：图片数据 TX
    %% ======================================================
    numBlocks_img = ceil(img_len / k2);
    pad_img = numBlocks_img*k2 - img_len;
    img_pad = [img_bits; zeros(pad_img,1)];

    tx_img_mod_all = complex([] , []);

    rx_bits_img_all = zeros(numBlocks_img*k2,1);
    s=0;
    for b = 1:numBlocks_img
        idx = (b-1)*k2 + 1 : b*k2;
        info = img_pad(idx);

        % LDPC
        cw = ldpcEncode(info, cfgEnc2);

        % BPSK
        modsig = bpskmod(double(cw));

        Es = 1;
        SNR_lin = 10^(SNR/10);
        Pn = Es / SNR_lin;

        h2 = 1/sqrt(2) * (randn + 1i*randn);
        rx_img_sig = modsig * h2;

        h0=h0+1;
        %if h0>100000,fprintf("h0→ %d\n,mc→ %d\n", h0,mc);end
        %if h0>100000,stopAll = true;end
        
        n2 = sqrt(Pn/2)*(randn(size(rx_img_sig)) + 1i*randn(size(rx_img_sig)));
        rx_img_sig = rx_img_sig + n2;

        var = 1/(10^(SNR/10));
        rx_img_llr   = bpskdemod(rx_img_sig,   h2, var, 'llr');
        
        dec2 = ldpcDecode(rx_img_llr, cfgDec2, maxnumiter);
        info2 = dec2(:); 
        rx_bits_img_all((b-1)*k2 + 1 : b*k2) = info2;

    end
    rx_img_bits = rx_bits_img_all(1:img_len);

    %% ======================================================
    %        Part B：图片 RX
    %% ======================================================

    %% 8. BPG 解码重建图像
    % 写入文件
    decodedBytes = bi2de(reshape(rx_img_bits,8,[])','left-msb');
    fid = fopen('recon.bpg','wb');
    fwrite(fid, decodedBytes,'uint8');
    fclose(fid);
    % 调用 bpgdec 解压
    outPng = fullfile(rx_img_dir, [base '.png']);
    outJng = fullfile(rx_img_dir, filename);
    cmd = sprintf('"%s" "%s" -o "%s"', ...
        'D:\Py\matlabCode\BPG_LDPC\bpg\bpgdec.exe', ...
        'recon.bpg', ...
        outPng);
    %system(cmd);
    % 删除文件
    status = system(cmd);
    if status ~= 0 || ~exist(outPng, 'file')
        warning('解码失败: %s', outPng);
            continue;
    else
        %reconImg = imread(outPng);
        %psnr_val = psnr(reconImg, img);
    end
    delete('recon.bpg');

    % 显示解码图像
    %rx_img =  imread(fullfile(rx_img_dir, filename));

    %rx_img_vec = rx_img(:);                       % 列向量 [pixels*channels x 1]
    %rx_img_bits_mat = de2bi(double(rx_img_vec), 8, 'left-msb'); % 每行一个像素的 8-bit
    %rx_img_bits = reshape(rx_img_bits_mat.', [], 1);  % 按列堆叠 -> 列主序，与 de2bi(:) 相对称
    %fprintf("Saved → %s\n", filename);
    % ==========================

    %   统计图像误码率
    % ==========================
    %img_bits_tx = img_bits1;
    %img_bits_rx = rx_img_bits;
    %img_errors  = img_errors + sum(img_bits_tx ~= img_bits_rx);
    
    % 累加比特总数
    %total_img_bits   = total_img_bits + length(img_bits);

    end

    if stopAll
        fprintf("Stop at mc = %d, h0 = %d\n", mc, h0);
        MC = mc;
        break;              % 跳出 mc（mc 是最后一次）
    end

    end
    %fprintf("ber at MC = %d, h0 = %d\n", MC, h0);%mc=35 H01001665

    %BER_img(si) = img_errors / total_img_bits;

end

% ==========================
%   保存 BER 结果到 MAT 文件
% ==========================
%out_mat = fullfile(ber_root, "ber_results.mat");

%save(out_mat, "SNR_list", "BER_img");

%fprintf("=== BER 统计已保存到 %s ===\n", out_mat);

fprintf("\n==== RX 保存完成 ====\n");
