clc; clear; close all;

%% 1. 读取原图
img = imread('image.png');  
figure; imshow(img); title('原图');

%% 2. BPG 压缩生成文件
bpgFile = 'image.bpg';
cmdEnc = sprintf('"%s" "%s" -o "%s"', ...
    'D:\Py\matlabCode\BPG_LDPC\bpg\bpgenc.exe', ...
    'image.png', ...
    bpgFile);
status = system(cmdEnc);
if status ~= 0
    error('BPG 编码失败，请检查路径和文件！');
end

%% 3. **直接复制原始 BPG 文件**
% ⚠ 不再处理 bit 流，保证解码成功
copyfile(bpgFile, 'recon.bpg');

%% 4. 调用 BPG 解码
cmdDec = sprintf('"%s" "%s" -o recon.png', ...
    'D:\Py\matlabCode\BPG_LDPC\bpg\bpgdec.exe', ...
    'recon.bpg');
status = system(cmdDec);
if status ~= 0
    error('BPG 解码失败！');
end

%% 5. 显示重建图像
reconImg = imread('recon.png');
figure; imshow(reconImg); title('重建图像');

%% 6. 计算 PSNR
psnr_val = psnr(reconImg, img);
fprintf('PSNR: %.2f dB\n', psnr_val);