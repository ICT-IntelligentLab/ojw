   

img = imread('test.jpg');

%% ============================================
%               参数
%% ============================================
target_CR = 20;      % 目标压缩率

save_path = 'temp.jpg';

Q=49;

%% JPEG压缩
    imwrite(img, save_path, ...
        'jpg', 'Quality', Q);

    %% 压缩后大小
    fileinfo_HOU = dir(save_path);
    fileinfo = dir('test.jpg');