import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
import keras
import JSCC_Model1 as JSCC_Model
import matplotlib.pyplot as plt
import numpy as np


def extract_patches(images, patch_size=32):
    patches = tf.image.extract_patches(
        images=images,
        sizes=[1, patch_size, patch_size, 1],
        strides=[1, patch_size, patch_size, 1],
        rates=[1, 1, 1, 1],
        padding='VALID'
    )

    # reshape成 (num_patches, 32, 32, 3)
    patches = tf.reshape(patches, (-1, patch_size, patch_size, 3))
    return patches

def load_images_tf_fullsize(folder):
    image_list = []

    for fname in os.listdir(folder):
        if fname.endswith('.jpg') or fname.endswith('.png'):
            path = os.path.join(folder, fname)

            # 读取图片，不改变尺寸
            img = tf.io.read_file(path)
            img = tf.image.decode_jpeg(img, channels=3)
            img = tf.cast(img, tf.float32)  # 保持 [0,255]

            image_list.append(img)

    return tf.stack(image_list)  # shape: (num_images, H, W, 3)


ratio = [0.08]
train_SNR = [1,2,4,6,8]
test_SNR = [0, 2, 4, 6, 8, 10,12,14,16]
lr = 1e-4
test_batch_size = 400
markers = ['*', '|', 'o', 's', 'd']
colors = ['#0072bd', '#d95319', '#edb120', '#7e2f8e', '#77ac30']
def psnr(y_true, y_pred):
    #print("y;")
    #print(y_true)
    #tf.print("y_true =", y_pred)
    return tf.image.psnr(y_true, y_pred, max_val=255.0)

def reconstruct_from_patches(patches, img_h=640, img_w=640, patch_size=32):
    patches_per_row = img_w // patch_size
    patches_per_col = img_h // patch_size

    # [N, 32, 32, 3] → [B, num_patches, 32, 32, 3]
    num_patches_per_img = patches_per_row * patches_per_col
    B = tf.shape(patches)[0] // num_patches_per_img

    patches = tf.reshape(
        patches,
        (B, patches_per_col, patches_per_row, patch_size, patch_size, 3)
    )

    # 交换维度方便拼接
    patches = tf.transpose(patches, [0, 1, 3, 2, 4, 5])

    # 拼回整图
    images = tf.reshape(
        patches,
        (B, img_h, img_w, 3)
    )

    return images

def eval(testX):
    testX = testX
    psnr_results = {tr_snr: [] for tr_snr in train_SNR}
    # 初始化为：{1: [], 4: [], 7: [], 13: [], 19: [] }
    for rt in ratio:
        for tr_snr in train_SNR:
            print('------------------------------loading model: ratio:{}, trainSNR:{}dB------------------------------'.format(rt, tr_snr))
            for te_snr in test_SNR:
                test_model = JSCC_Model.JSCC(rt, te_snr)
                # Build model
                input = keras.Input(shape=(32, 32, 3))
                output = test_model(input)
                test_model = keras.Model(input, output)
                test_model.compile(optimizer=keras.optimizers.Adam(learning_rate=lr), loss=keras.losses.mean_squared_error, metrics=[psnr])
                test_model.load_weights(f'./checkpoint/JSCC_ratio{rt}_trainSNR{tr_snr}.weights.h5')

                recon_patches = test_model.predict(testX, batch_size=test_batch_size)
                recon_images = reconstruct_from_patches(recon_patches)
                gt_images = reconstruct_from_patches(testX)
                test_psnr = tf.reduce_mean(
                    tf.image.psnr(recon_images, gt_images, max_val=255.0)
                )

                print('\n testing: testSNR:{}dB, PSNR:{}dB \n'.format(te_snr, test_psnr))
                psnr_results[tr_snr].append(float(test_psnr))

                #test_loss, test_psnr = test_model.evaluate(testX, testX, batch_size=test_batch_size, verbose=1)
                #print('\n  testing: testSNR:{}dB, test_loss:{}, test_psnr:{}dB \n'.format(te_snr, test_loss, test_psnr))
                #psnr_results[tr_snr].append(test_psnr)
    return psnr_results

def visualize(testX):
    # 随机选取一张原始图片
    random_index = np.random.randint(0, len(testX))
    original_image = testX[random_index].numpy()
    # 创建 6x10 的子图布局
    fig, axes = plt.subplots(6, 10, figsize=(18, 10))
    # 标注第一行
    axes[0, 0].imshow(original_image.astype('uint8'))
    axes[0, 0].axis('off')
    for j in range(1, 10):
        axes[0, j].text(0.5, 0.5, f'Test SNR: {test_SNR[j - 1]}dB', horizontalalignment='center', verticalalignment='center')
        axes[0, j].axis('off')
    # 标注第一列
    for i in range(1, 6):
        axes[i, 0].text(0.5, 0.5, f'Train SNR: {train_SNR[i - 1]}dB', horizontalalignment='center', verticalalignment='center')
        axes[i, 0].axis('off')
    # 填充剩余的接收端恢复图
    for rt in ratio:
        for i, tr_snr in enumerate(train_SNR):
            for j, te_snr in enumerate(test_SNR):
                test_model = JSCC_Model.JSCC(rt, te_snr)
                # Build model
                input = keras.Input(shape=(32, 32, 3))
                output = test_model(input)
                test_model = keras.Model(input, output)
                test_model.compile(optimizer=keras.optimizers.Adam(learning_rate=lr), loss=keras.losses.mean_squared_error, metrics=[psnr])
                test_model.load_weights(f'./checkpoint/JSCC_ratio{rt}_trainSNR{tr_snr}.weights.h5')
                input_image = np.expand_dims(original_image, axis=0)
                restored_image = test_model.predict(input_image)[0]
                axes[i + 1, j + 1].imshow(restored_image.astype('uint8'))
                axes[i + 1, j + 1].axis('off')
    fig.suptitle('AWGN channel visualization (k/n=1/12)')
    plt.show()



if __name__ == '__main__':
    # 获取测试集
    #(_, _), (testX, _) = keras.datasets.cifar10.load_data()
    #testX = testX.astype('float32')

    testX = load_images_tf_fullsize("images_243")
    testX = tf.cast(testX , tf.float32)
    testX = extract_patches(testX, 32)

    # PSNR曲线
    psnr_results = eval(testX)
    plt.figure(figsize=(8, 8))
    for i, tr_snr in enumerate(train_SNR):
        plt.plot(test_SNR, psnr_results[tr_snr], marker=markers[i], color=colors[i], label=f"trainSNR:{tr_snr} dB")
    plt.xlabel('SNR_test (dB)')
    plt.ylabel('PSNR (dB)')
    plt.title('AWGN channel(k/n=1/12)')
    plt.legend()
    plt.xlim(0, 16)
    plt.grid()
    plt.show()
    # 图像可视化
    visualize(testX)
    

