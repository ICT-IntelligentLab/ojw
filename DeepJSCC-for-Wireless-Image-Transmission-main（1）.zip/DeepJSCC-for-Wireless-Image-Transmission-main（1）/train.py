import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import keras
import JSCC_Model1 as JSCC_Model

import tensorflow as tf

def extract_patches(images, patch_size=32):
    patches = tf.image.extract_patches(
        images=images,
        sizes=[1, patch_size, patch_size, 1],
        strides=[1, patch_size, patch_size, 1],
        rates=[1, 1, 1, 1],
        padding='VALID'
    )

    # reshape成 (num_patches, 32, 32, 3)
    patches = tf.reshape(patches, (-1, patch_size, patch_size, 3))
    return patches

def load_images_tf_fullsize(folder):
    image_list = []

    for fname in os.listdir(folder):
        if fname.endswith('.jpg') or fname.endswith('.png'):
            path = os.path.join(folder, fname)

            # 读取图片，不改变尺寸
            img = tf.io.read_file(path)
            img = tf.image.decode_jpeg(img, channels=3)
            img = tf.cast(img, tf.float32)  # 保持 [0,255]

            image_list.append(img)

    return tf.stack(image_list)  # shape: (num_images, H, W, 3)

ratio = [0.08]
train_SNR = [4,6,8]
test_SNR = [0, 2, 4, 6, 8, 10, 12, 14, 16]
batch_size = 128
epochs = 10
lr = 1e-4

def train():
    #trainX shape:(50000, 32, 32, 3)  testX shape: (10000, 32, 32, 3)
    #(trainX, _), (_, _) = keras.datasets.cifar10.load_data()

    trainX = load_images_tf_fullsize("images_all")
    trainX = tf.cast(trainX, tf.float32)

    trainX = extract_patches(trainX, 32)
    print(trainX.shape)

    print(trainX.shape)
    for rt in ratio:
        for snr in train_SNR:
            print('***************ratio:{}, SNR:{}dB***************'.format(rt, snr))

            model = JSCC_Model.JSCC(rt, snr)
            #model.build(input_shape=(None, 640, 640, 3))  # ❗ 手动build# Build model
            input = keras.Input(shape=(32, 32, 3))
            output = model(input)
            model = keras.Model(input, output)
            model.compile(optimizer=keras.optimizers.Adam(learning_rate=lr), loss=keras.losses.mean_squared_error)
            save_func = keras.callbacks.ModelCheckpoint(filepath=f'./checkpoint/JSCC_ratio{rt}_trainSNR{snr}.weights.h5', save_weights_only=True)
            model.fit(x=trainX, y=trainX, epochs=epochs, verbose=1, batch_size=batch_size, callbacks=[save_func])
            ## 检查点回调
            #save_func = keras.callbacks.ModelCheckpoint(
            #    filepath=f'./checkpoint/JSCC_ratio{rt}_trainSNR{snr}.weights.h5',
            #    save_weights_only=True,
            #    monitor='val_loss',  # 监控验证集 loss
            #    save_best_only=True  # 只保存验证集 loss 最小的模型
            #)
#
            ## 使用 validation_split 自动划分 15% 数据为验证集
            #model.fit(
            #    x=trainX,
            #    y=trainX,
            #    epochs=epochs,
            #    verbose=1,
            #    batch_size=batch_size,
            #    validation_split=0.15,  # 15% 数据作为验证集
            #    callbacks=[save_func]
            #)
#

if __name__ == '__main__':
    train()     

