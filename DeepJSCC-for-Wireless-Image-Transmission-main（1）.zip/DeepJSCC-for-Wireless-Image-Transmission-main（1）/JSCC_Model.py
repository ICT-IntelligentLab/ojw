import tensorflow as tf
import numpy as np
import keras


class JSCC_Endcoder(keras.layers.Layer):
    def __init__(self, c, k):
        super(JSCC_Endcoder, self).__init__(name='JSCC_Encoder')
        self.k = k  # k是信道带宽 k/n 是压缩比
        self.conv1 = keras.layers.Conv2D(12, 5, strides=2, padding='same', activation='relu')
        self.conv2 = keras.layers.Conv2D(48, 5, strides=2, padding='same')
        #self.conv2 = keras.layers.Conv2D(48, 5, strides=2, padding='same', activation='relu')
        #self.conv3 = keras.layers.Conv2D(48, 5, strides=1, padding='same', activation='relu')
        #self.conv4 = keras.layers.Conv2D(12, 3, strides=1, padding='same')  # 输出2通道 real/imag

    def Encoder_Norm(self, z):
        # tmp = tf.math.sqrt(tf.reduce_sum(tf.math.conj(z) * z))
        # tmp2 = tf.complex(tf.math.sqrt(self.k), tf.constant(0.0, dtype=tf.float32))
        # return tmp2 * z / tmp # 假设功率P=1
        # z: (batch, k), complex64
        power = tf.reduce_sum(tf.abs(z) ** 2, axis=1, keepdims=True)  # float32
        # 转成 complex
        power_c = tf.complex(tf.sqrt(power + 1e-8), 0.0)
        factor = tf.complex(tf.sqrt(tf.cast(self.k*2, tf.float32)), 0.0)
        z = factor * z / power_c
        return z

    def call(self, input):
        x = input / 255.0
        x = self.conv1(x)
        x = self.conv2(x)
        #x = self.conv3(x)
        #x = self.conv4(x)  # (batch, H', W', 2)

        x = tf.reshape(x, (-1, self.k, 2))  # (batch, k, 2)
        z = tf.complex(x[..., 0], x[..., 1])  # (batch, k)
        # x = tf.reshape(x, (2, -1))
        # z = tf.complex(x[0], x[1])
        z = self.Encoder_Norm(z)
        return z


class JSCC_Decoder(keras.layers.Layer):
    def __init__(self, c, k):
        super(JSCC_Decoder, self).__init__(name='JSCC_Decoder')
        self.c = c
        self.k = k
        # 转换成卷积可用形状
        self.H = 160
        self.W = 160
        self.C = k * 2 // (self.H * self.W)  # 确保元素总数一致
        self.convT1 = keras.layers.Conv2DTranspose(48, 5, strides=1, padding='same', activation='relu')
        #self.convT2 = keras.layers.Conv2DTranspose(128, 5, strides=1, padding='same', activation='relu')
        self.convT3 = keras.layers.Conv2DTranspose(12, 5, strides=2, padding='same', activation='relu')
        self.convT4 = keras.layers.Conv2DTranspose(3, 5, strides=2, padding='same', activation='sigmoid')


    def call(self, input):
        # x = tf.concat([tf.math.real(input), tf.math.imag(input)], 0)
        x = tf.concat([tf.math.real(input), tf.math.imag(input)], axis=-1)
        x = tf.reshape(x, (-1, self.H, self.W, self.C))  # reshape 成 4D
        x = self.convT1(x)
       #x = self.convT2(x)
        x = self.convT3(x)
        x = self.convT4(x)
        x = x * 255.0
        return x


class JSCC(keras.Model):
    def __init__(self, ratio, SNR):
        super(JSCC, self).__init__(name='JSCC')
        self.k = 614400
        self.c = int(self.k / 64.0)
        self.snr = SNR
        self.noi_pow = 1.0 / (10 ** (self.snr / 10))
        self.encoder = JSCC_Endcoder(self.c, self.k)
        self.decoder = JSCC_Decoder(self.c, self.k)

    def call(self, x):
        z = self.encoder(x)
        # self.noise = np.random.normal(0, np.sqrt(self.noi_pow), z.shape)
        real_noise = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=np.sqrt(self.noi_pow))
        imag_noise = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=np.sqrt(0))
        self.comp_noise = tf.complex(real_noise, imag_noise)

        real_h = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=1)
        imag_h = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=1)
        self.comp_h = tf.complex(real_h, imag_h)

        z_hat = (z)  #+ self.comp_noise) #/ self.comp_h
        x_hat = self.decoder(z_hat)
        return x_hat
