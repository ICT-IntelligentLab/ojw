import tensorflow as tf
import numpy as np
import keras

class JSCC_Endcoder(keras.layers.Layer):
    def __init__(self, c, k):
        super(JSCC_Endcoder, self).__init__(name='JSCC_Encoder')
        self.k = k # k是信道带宽 k/n 是压缩比
        self.conv1 = keras.layers.Conv2D(filters=16, kernel_size=5, strides=2, padding='same', name='conv1')
        self.prelu1 = keras.layers.ReLU(name='prelu1')
        self.conv2 = keras.layers.Conv2D(filters=32, kernel_size=5, strides=2, padding='same', name='conv2')
        self.prelu2 = keras.layers.ReLU(name='prelu2')
        #self.conv21 = keras.layers.Conv2D(filters=16, kernel_size=11, strides=2, padding='same', name='conv21')
        #self.prelu21 = keras.layers.ReLU(name='prelu21')
        #self.conv22 = keras.layers.Conv2D(filters=32, kernel_size=11, strides=2, padding='same', name='conv22')
        #self.prelu22 = keras.layers.ReLU(name='prelu22')
        ##self.conv23 = keras.layers.Conv2D(filters=32, kernel_size=5, strides=2, padding='same', name='conv23')
        #self.prelu23 = keras.layers.ReLU(name='prelu23')
        #self.conv24 = keras.layers.Conv2D(filters=32, kernel_size=11, strides=1, padding='same', name='conv24')
        #self.prelu24 = keras.layers.ReLU(name='prelu24')
        self.conv3 = keras.layers.Conv2D(filters=32, kernel_size=5, strides=1, padding='same', name='conv3')
        self.prelu3 = keras.layers.ReLU(name='prelu3')
        self.conv4 = keras.layers.Conv2D(filters=32, kernel_size=5, strides=1, padding='same', name='conv4')
        self.prelu4 = keras.layers.ReLU(name='prelu4')
        self.flatten = keras.layers.Flatten(name='flatten')
        self.fc = keras.layers.Dense(2*k, name='fc')
    def Encoder_Norm(self, z):
        #tmp = tf.math.sqrt(tf.reduce_sum(tf.math.conj(z) * z))
        #tmp2 = tf.complex(tf.math.sqrt(self.k), tf.constant(0.0, dtype=tf.float32))
        #return tmp2 * z / tmp # 假设功率P=1
        # z: (batch, k), complex64
        power = tf.reduce_sum(tf.abs(z) ** 2, axis=1, keepdims=True)  # float32
        # 转成 complex
        power_c = tf.complex(tf.sqrt(power + 1e-9), 0.0)
        factor = tf.complex(tf.sqrt(tf.cast(self.k, tf.float32)), 0.0)
        z = factor * z / power_c
        return z
    def call(self, input):
        x = input/255.0
        x = self.conv1(x)
        x = self.prelu1(x)

        x = self.conv2(x)
        x = self.prelu2(x)

       #x = self.conv21(x)
       #x = self.prelu21(x)
       #x = self.conv22(x)
       #x = self.prelu22(x)
       #x = self.conv23(x)
       #x = self.prelu23(x)
       #x = self.conv24(x)
       #x = self.prelu24(x)

        x = self.conv3(x)
        x = self.prelu3(x)

        x = self.conv4(x)
        x = self.prelu4(x)

        x = self.flatten(x)
        x = self.fc(x)

        x = tf.reshape(x, (-1, self.k, 2))  # (batch, k, 2)
        z = tf.complex(x[..., 0], x[..., 1])  # (batch, k)
        #x = tf.reshape(x, (2, -1))
        #z = tf.complex(x[0], x[1])
        z = self.Encoder_Norm(z)
        return z
    

class JSCC_Decoder(keras.layers.Layer):
    def __init__(self, c, k):
        super(JSCC_Decoder, self).__init__(name='JSCC_Decoder')
        self.c = c
        self.k = k
        self.fc = keras.layers.Dense(2*k, name='fc')  # 你可以先固定成 8×8×32
        self.prelu6 = keras.layers.ReLU(name='prelu6')
        #self.reshape = keras.layers.Reshape((8, 8, 32), name='reshape')
        self.trans_conv2 = keras.layers.Conv2DTranspose(filters=32, kernel_size=5, strides=1, padding='same', name='trans_conv2')
        self.prelu7 = keras.layers.ReLU(name='prelu7')
        #self.trans_conv3 = keras.layers.Conv2DTranspose(filters=32, kernel_size=5, strides=1, padding='same', name='trans_conv3')
        #self.prelu8 = keras.layers.ReLU(name='prelu8')
        self.trans_conv4 = keras.layers.Conv2DTranspose(filters=32, kernel_size=5, strides=1, padding='same', name='trans_conv4')
        self.prelu9 = keras.layers.ReLU(name='prelu9')
        self.trans_conv10 = keras.layers.Conv2DTranspose(filters=32, kernel_size=5, strides=2, padding='same', name='trans_conv10')
        self.prelu10 = keras.layers.ReLU(name='prelu10')
        #self.trans_conv41 = keras.layers.Conv2DTranspose(filters=32, kernel_size=5, strides=2, padding='same', name='trans_conv41')
        #self.prelu41 = keras.layers.ReLU(name='prelu41')
        #self.trans_conv42 = keras.layers.Conv2DTranspose(filters=32, kernel_size=5, strides=2, padding='same', name='trans_conv42')
        #self.prelu42 = keras.layers.ReLU(name='prelu42')
        self.trans_conv43 = keras.layers.Conv2DTranspose(filters=16, kernel_size=5, strides=2, padding='same', name='trans_conv43')
        self.prelu43 = keras.layers.ReLU(name='prelu43')
        self.trans_conv5 = keras.layers.Conv2DTranspose(filters=3, kernel_size=5, strides=1, padding='same', name='trans_conv5')
    def call(self, input):
        #x = tf.concat([tf.math.real(input), tf.math.imag(input)], 0)
        x = tf.concat([tf.math.real(input), tf.math.imag(input)], axis=-1)
        x = self.fc(x)
        x = self.prelu6(x)
        x = tf.reshape(x, (-1, 8, 8, 32))
        x = self.trans_conv2(x)
        x = self.prelu7(x)
        #x = self.trans_conv3(x)
        #x = self.prelu8(x)
        x = self.trans_conv4(x)
        x = self.prelu9(x)
        x = self.trans_conv10(x)
        x = self.prelu10(x)
        #x = self.trans_conv41(x)
        #x = self.prelu41(x)
        #x = self.trans_conv42(x)
        #x = self.prelu42(x)
        x = self.trans_conv43(x)
        x = self.prelu43(x)
        x = self.trans_conv5(x)
        x = keras.activations.sigmoid(x)
        x = x*255.0
        return x
        

class JSCC(keras.Model):
    def __init__(self, ratio, SNR):
        super(JSCC, self).__init__(name='JSCC')
        self.k = 1024
        self.c = int( self.k / 64.0)
        self.snr = SNR
        self.noi_pow = 1.0 / (10 ** (self.snr / 10))
        self.encoder = JSCC_Endcoder(self.c, self.k)
        self.decoder = JSCC_Decoder(self.c, self.k)
    def call(self, x):
        z = self.encoder(x)

        #self.noise = np.random.normal(0, np.sqrt(self.noi_pow), z.shape)
        #real_noise = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=np.sqrt(self.noi_pow/2))
        #imag_noise = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=np.sqrt(self.noi_pow/2))
        #self.comp_noise = tf.complex(real_noise, imag_noise)
#
        #real_h = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=1/2)
        #imag_h = tf.random.normal(shape=tf.shape(z), mean=0.0, stddev=1/2)
        #self.comp_h = tf.complex(real_h, imag_h)

        batch_size = tf.shape(z)[0]

        # 每张图一个复数 h
        real_h = tf.random.normal((batch_size, 1), mean=0.0, stddev=1 / np.sqrt(2))
        imag_h = tf.random.normal((batch_size, 1), mean=0.0, stddev=1 / np.sqrt(2))
        comp_h = tf.complex(real_h, imag_h)  # shape: (batch,1,1,1)

        # 噪声也同理
        real_noise = tf.random.normal((batch_size, 1), mean=0.0, stddev=np.sqrt(self.noi_pow / 2))
        imag_noise = tf.random.normal((batch_size, 1), mean=0.0, stddev=np.sqrt(self.noi_pow / 2))
        comp_noise = tf.complex(real_noise, imag_noise)

        #z_hat = z + self.comp_noise
        z_hat = (z * comp_h + comp_noise) / comp_h

        x_hat = self.decoder(z_hat)
        return x_hat
